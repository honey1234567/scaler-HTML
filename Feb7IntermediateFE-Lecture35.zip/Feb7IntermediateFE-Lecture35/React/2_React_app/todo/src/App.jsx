import './App.css'
import Todo from "./components/Todo";
function App() {

  return (
    <>
      <h1>Todo App</h1>
      <Todo></Todo>
    </>
  )
}

export default App
