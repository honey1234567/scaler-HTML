import React from 'react'

function List({tasks,handleDelete}){
    return <div className="list">
    <ul>
    {tasks.map(({inputValue:task,id})=>(
        <div key={id}>
        <li>{task}</li>
        <button onClick={()=>handleDelete(id)}>Delete</button>
        </div>
    )
    )}
    </ul>
</div>
}

export default List