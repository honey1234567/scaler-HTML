import React from 'react'
import { useState, useRef} from 'react'

function Stopwatch() {
    const [time,setTime]=useState(0);
    //my id variable needs to persist, even after component re-renders. so we use useRef();
    // What is ref used for ? 
    // a. Optimizing render cycle 
    // b. storing values that can survive re-renders 
    // c. can create reference to redux
    const idObj=useRef();
    console.log(idObj);

    const handleStart=()=>{
        idObj.current=setInterval(()=>{
            // setTime(time+1)
            setTime((time)=>time+1); //when u want to update your state based on the latest state value . 
            //after updating this state , we acess the state, but it shows us old state
            //noticing this behaviour, we can conclude that stateChange is an async operation 
            // console.log(time);
        },1000)
        //my idObj is going to persisit, it is not going to lose value on re-renders. 
        console.log(idObj);
    }

    const handlePause=()=>{
        //timer should stop 
        //id 
        clearInterval(idObj.current);
    }

    const handleReset=()=>{
        //clear the interval 
        //reset the time as well 
        clearInterval(idObj.current);
        setTime(0);
    }

  return (
    <>
    <h1>Stop Watch</h1>
    <h2>{time}</h2>
    <button onClick={handleStart}>Start</button>
    <button onClick={handlePause}>Pause</button>
    <button onClick={handleReset}>Reset</button>
    </>
  )
}

export default Stopwatch