import React from 'react'
import styleObject from "./style.module.css"
function InfinteScrolling() {
    console.log(styleObject);
  return (
    // <div>InfinteScrolling</div>
    <h1 className={styleObject.heading}>Hello i lazy load</h1>
  )
}

export default InfinteScrolling