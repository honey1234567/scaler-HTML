// //shadowing 
// var a=10;
// {
//     var a=100;
//     console.log(a); //100
// }
// console.log(a);//100

// //shadowing 
// two variables same name but different scope 
// var a=10;
// {
//     let a=100;
//     console.log(a); //100
// }
// console.log(a);//10

//illegal shadowing 
// two variables same name and same scope 
// let a=10;
// {
//     var a=100;
//     console.log(a);
// }
// console.log(a);