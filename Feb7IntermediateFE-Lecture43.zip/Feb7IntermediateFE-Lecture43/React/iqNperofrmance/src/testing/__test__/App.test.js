import{render, screen} from "@testing-library/react"
import App from "../../App"
test("app renders text correctly",()=>{
    //app comp has been rendered in isolation
    // Arrange
    render(<App></App>)
    //we want a screen so that we can know what has been renderd. 
    //Act
    const liElement=screen.getByText(/Learn react/);
    //assert
    expect(liElement).toBeInTheDocument();
})

