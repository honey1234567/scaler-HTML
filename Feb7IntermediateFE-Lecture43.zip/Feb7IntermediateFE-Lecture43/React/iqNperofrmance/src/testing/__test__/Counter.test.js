import {fireEvent, render,screen} from "@testing-library/react"
import Counter from "../../components/Counter";


describe("Counter test cases",()=>{
    //initil state
    test("initial state check",()=>{
        render(<Counter></Counter>)

        const counterText=screen.getByText("Counter");
        const CountValue=screen.getByText("0");
        const plusBtn=screen.getByText("+");
        const minusBtn=screen.getByText("-");

        //assert -> compare 
        expect(counterText).toBeInTheDocument()
        expect(CountValue).toBeInTheDocument()
        expect(plusBtn).toBeInTheDocument()
        expect(minusBtn).toBeInTheDocument()
    })
    //inc by 1 
    test("inc by 1 ",()=>{
        render(<Counter></Counter>);
        const plusBtn=screen.getByText("+");
        fireEvent.click(plusBtn);
        const CountValue=screen.getByText("1");
        expect(CountValue).toBeInTheDocument();

    })

    test("dec by 2 ",()=>{
        render(<Counter></Counter>);
        const minusBtn=screen.getByText("-");
        fireEvent.click(minusBtn);
        fireEvent.click(minusBtn);
        const CountValue=screen.getByText("-2");
        expect(CountValue).toBeInTheDocument();

    })
})
 
//dec by 2 