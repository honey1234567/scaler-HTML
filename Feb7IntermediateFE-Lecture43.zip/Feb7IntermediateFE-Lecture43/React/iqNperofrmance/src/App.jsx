import { useState } from "react";
// import reactLogo from "./assets/react.svg";
// import viteLogo from "/vite.svg";
import "./App.css";
// import UseState from './components/UseState'
// import UseReducer from "./components/UseReducer"
import FormReducer from "./components/FormReducer";
import CalcMemo from "./components/CalcMemo";
import MemoApp from "./components/MemoApp";
import UseCallback from "./components/UseCallback";
import ClassCounter from "./components/ClassCounter";

function App() {
  const [count, setCount] = useState(0);
  const [name, setName] = useState("Scaler");

  return (
    <>
    <li>Learn react</li>
      {/* <UseState></UseState> */}
      {/* <UseReducer></UseReducer> */}
      {/* <FormReducer></FormReducer> */}
      {/* <CalcMemo></CalcMemo> */}
      {/* <MemoApp></MemoApp> */}
      {/* <UseCallback></UseCallback> */}
      <ClassCounter></ClassCounter>
    </>
  );
}

export default App;

// //jsx

// const element = <h1 title="foo">Hello</h1>

// //js -> babel
// const element = /*#__PURE__*/_jsx("h1", {
//   title: "foo",
//   children: "Hello"
// });

// //this is retunned to us by calling react .createElement
// const element = {
//   type: "h1",
//   props: {
//     title: "foo",
//     children: "Hello",
//   },
// }
// ​
// this object is used to create dom tree

// const vdom ={
//   type: 'div',

//   props: {
//       class: "container",
//       children: [
//           {
//               type: 'h1',
//               props: {
//                   children: ' this is '
//               }
//           },
//           {
//               type: 'p', props: {
//                   class: 'paragraph',
//                   children: [
//                       ' I am ',
//                       {
//                           type: (props) => ({
//                               type: "button", props:
//                                   { children: props.counter + "Clicks" }
//                           }),
//                           props: { counter: 1 }
//                       }
//                       ,
//                       ' from'
//                   ]
//               }
//           }
//       ]
//   }
// }
// ```

// <p className="paragraph">I am <button >{counter} Clicks</button>  from</p>

// //mounted code -> with all initilizations of state props
// <p className="paragraph">I am <button >1 Clicks</button>  from</p>

// UI
// I am 1 Clicks from

// if the React elements represent components, React instantiates the component classes or functional components. This initializes the component's state, props, and other internal data, preparing them for rendering
