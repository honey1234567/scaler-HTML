import React, { useState, useMemo, useEffect } from 'react';

function CalcMemo() {
    const [count, setCount] = useState(0);
    const [address, setAddress] = useState('');

    /*****
     * you have lot of costly calculation  -> variable (does not change -> reuse the result )
     * 
     * */
    // some action
    function calculateCount(){
        console.log("Result was calculated");
        return count ** count;
    }
    // const result=calculateCount();

    const result=useMemo(()=>calculateCount(),[count])

    // useEffect(()=>{

    // },[count])
     

    return (
        <div>
            <h1>Count: {count}</h1>
            <h2>Memoized Value: {result}</h2>
            <button onClick={() => setCount(count + 1)}>Increment Count</button>
            <label>
                Address{': '}
                <input value={address} onChange={e => setAddress(e.target.value)} />
            </label>
        </div>
    );
}

export default CalcMemo