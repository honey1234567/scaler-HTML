import React, { Component,PureComponent } from 'react'

export default class ClassCounter extends Component {
    constructor(props){
        console.log("constructor is called");
        //super is used to call the constructor of the Component(Parent) class 
        super(props);
        this.state={
            count:0,
            value:"",
            error:false
        }
        let thisOfConstructor=this;
        this.decCount=this.decCount.bind(thisOfConstructor)
    }



//arrow function 
    incCount=()=>{
        this.setState({count:this.state.count+1})
    }

    //conventional function 
    decCount=function (){
        // console.log(this);
        this.setState({count:this.state.count-1})
    }
    // useEffect({}, [])
    componentDidMount(){
        console.log("run once after first render");
    }

    // useEffect({}, )
    componentDidUpdate(){
        console.log("i will run after every render");
    }

    //cleanup variation of useEffect
    componentWillUnmount(){
        console.log("i am unmounting");
    }

    shouldComponentUpdate(){
        console.log("i am asked before re rendering");
        //my component should update 
        return true;
    }


  render() {
    console.log("render is called");
    return (
        <>
        <h1>Counter</h1>
        <h2>{this.state.count}</h2>
        <div>
            <button onClick={this.incCount} >+</button>
            <button onClick={this.decCount}>-</button>
        </div>

    </>
    )
  }
}



// classCounter={
//     decCount=function(){

//     }
// }

// this.decCount