import React, { useCallback, useState } from 'react'

function UseCallback() {
    const [count,setCount]=useState(0);
    const [value,setValue]=useState("");

    const handleClick=()=>{
        setCount(count=>count+1);
    }

    const memoizedHandleClick=useCallback(handleClick,[count])

  return (
    <div>
        <input type="text" onChange={(e)=>setValue(e.target.value)} />
        <p>Count : {count}</p>
        <MemoizedChildComponent parentClick={memoizedHandleClick} count={count}></MemoizedChildComponent>
        
    </div>
  )
}
//if we want our compo to only re-render when state is chnaged 
const MemoizedChildComponent=React.memo(ChildComponent) 
function ChildComponent({parentClick,count}){
    console.log("Child component is rendered");;
    return(
        <>
        <button onClick={()=>parentClick()}>child says Increment count from
                {count}</button>
        </>
    )
}

export default UseCallback