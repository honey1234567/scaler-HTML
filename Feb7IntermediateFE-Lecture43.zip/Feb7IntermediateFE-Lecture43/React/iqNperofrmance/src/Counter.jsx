import React, { Component } from 'react'

export default class Counter extends Component {
//state creation 
//async call 

  render() {
    return (
      <div>
        <h1>Hello how are you </h1>
        <h2>I am bad</h2>
      </div>
      
    )
  }
}


