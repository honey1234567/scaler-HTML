import {configureStore} from "@reduxjs/toolkit";
import counterSlice from "./counterSlice";
import todoSlice from "./todoSlice";
console.log(todoSlice);
const store=configureStore({
    // it stores all the sections 
    reducer:{
        counterState:counterSlice.reducer,
        todoState:todoSlice.reducer
    }
});

// console.log(store);

export default store
