import React,{useEffect, useState} from 'react'

// custom Hook 
//     1. should be a pure js function 
//     2. should always start with "use"

// Components serve the purpose to reuse our UI 

// Custom hooks are used for reusing the logic part such as data call 


export default function useFetchParams(...dependency){
    console.log(dependency);
    const [data,setData]=useState([]);
    const [loader,setLoader]=useState(true);
    const [error,setError]=useState(""); //falsy value 
    useEffect(()=>{
        async function handler(){
            try{
                setLoader(true);
                let resp=await fetch(`https://jsonplaceholder.typicode.com/comments?_page=${dependency[0]}&_limit=10`);
                let d=await resp.json();
                console.log(d);
                setData([...data,...d]);
            }
            catch(err){
                setError(err.message);
            }
            finally{
                setLoader(false);
            }
        }
        handler()
    },dependency)
    return [data,loader,error]
}
