import React, {createContext, useContext, useState } from 'react'
// const contextWrapper=createContext(); // creates store -> contextWrapper is name of the store 
const storeApnaBazaar=createContext("hello"); // creates store -> storeApnaBazaar is name of the store 
//hello is a fallabck value , it is used when we do not get any data from store . 
console.log(storeApnaBazaar);
//data to be put inside store
const data={
    msg:"Hello",
    pageNum:1,
    dal:"5kg",
    rice:"10kg",
    rajma:"20kg"
}
function Context() {
  return (
    // wrapping the top most component of react with the ContextWrapper(store) and providing the data of our store
    <>
    <storeApnaBazaar.Provider value={data}>
      {/* customer list  */}
    <GrandParent></GrandParent>
    </storeApnaBazaar.Provider>
    </>
  )
}
// all these components are now allowed to shjop from store 
function GrandParent(){
  let [name,setName]=useState("InterviewBit");
  console.log("Grandparent was rendered");
    return<>
    <h3>GrandParent</h3>
    <div>⬇️</div>
    <Parent1 name={name} setName={setName}></Parent1>
    </>
}

function Parent1({name,setName}){
  console.log("Parent1 was rendered");
    return<>
    <h3>Parent1</h3>
    <div>⬇️</div>
    <Parent2 name={name} setName={setName}></Parent2>
    </>
}

function Parent2({name,setName}){
  console.log("Parent2 was rendered");
  return<>
  <h3>Parent2</h3>
  <div>⬇️</div>
  <Child name={name} setName={setName}></Child>
  </>
}

function Child({name,setName}){
  console.log("Child was rendered");
  //if child comp needs something from store , he can consume it .
    // 1. Consumer 
    // 2. useContext()
    // const {msg}=useContext(contextWrapper);
    const {rice}=useContext(storeApnaBazaar);
    return<>
    <h3>Child</h3>
    <div>⬇️</div>
    {/* <p>{msg}</p> */}
    {/* <storeApnaBazaar.Consumer>
      { (dataObj)=><p>{dataObj.rice}</p>}
    </storeApnaBazaar.Consumer> */}
    <p>{rice}</p>
    <p>{name}</p>
    <button onClick={()=>setName("Scaler")}>Change Name</button>
    </>
}

export default Context