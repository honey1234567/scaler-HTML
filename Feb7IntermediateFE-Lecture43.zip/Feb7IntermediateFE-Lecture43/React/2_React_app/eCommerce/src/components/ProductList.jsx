import React from "react";
import styleObj from "../style.module.css";
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import {useSelector,useDispatch} from "react-redux";
import {actions} from "../redux/slices/cartSlice";
function ProductList({ product }) {
  const {cartQuantity,cartProducts}=useSelector((store=>store.cartState));
  const dispatch=useDispatch()
  const handleAdd=(product)=>{
    //maybe validate and serialise the request
    dispatch(actions.addToCart(product))
  }

  const handleRemove=(product)=>{
    dispatch(actions.removeFromCart(product))
  }
  return (
    <>
      <div className={styleObj.product}>
        <img src={product.image} alt="" className={styleObj.product_image} />
        <div className={styleObj.title}>{product.title}</div>
        <div className={styleObj.price}>$ {product.price}</div>
        <div style={{display:"flex", justifyContent:"center", marginTop:"0.5rem"}}>
          <button onClick={()=>handleAdd(product)}><AddIcon></AddIcon></button>
        
        <p style={{alignContent:"center", marginLeft:"5px", marginRight:"5px"}}>{<IndQty cartProducts={cartProducts} id={product.id}></IndQty>}</p>
        <button onClick={()=>handleRemove(product)}><RemoveIcon></RemoveIcon></button>
      </div>
      </div>
     
    </>
  );
}

function IndQty({cartProducts,id}){
  let qty=0;
  cartProducts.forEach((product)=>{
    if(product.id==id){
      qty=product.qty;
    }
  })
  return (
    <>{qty}</>
  )
}
export default ProductList;
