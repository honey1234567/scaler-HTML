import React, {createContext, useContext } from 'react'
const ContextWrapper=createContext(); // creates store -> contextWrapper is name of the store 
//data to be put inside store
const data={
    msg:"Hello",
    pageNum:1
}
function Context() {
  return (
    // wrapping the top most component of react with the ContextWrapper(store) and providing the data of our store 
    <ContextWrapper.Provider value={data}>
    <GrandParent></GrandParent>
    </ContextWrapper.Provider>
  )
}

function GrandParent(){
    return<>
    <h3>GrandParent</h3>
    <div>⬇️</div>
    <Parent></Parent>
    </>
}

function Parent(){
    return<>
    <h3>Parent</h3>
    <div>⬇️</div>
    <Child></Child>
    </>
}

function Child(){
    const {msg}=useContext(ContextWrapper);
    return<>
    <h3>Child</h3>
    <div>⬇️</div>
    <p>{msg}</p>
    </>
}

export default Context