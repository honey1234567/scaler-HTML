import React, { useEffect, useState } from "react";
import { Routes, Route, Outlet, useParams,Link,Navigate} from "react-router-dom";
function Routing() {
  return (
    <>
      <div>Navbar</div>
      <ul>
        <Link to="/"><li>Home</li></Link>
        <Link to="/about"><li>About</li></Link>
      </ul>
      <Routes>
        <Route path="/" element={<Home></Home>}></Route>
        <Route path="/about" element={<About></About>}>
          {/* subrouting */}
          <Route path="company" element={<Company></Company>}></Route>
          <Route path="ceo" element={<Ceo></Ceo>}></Route>
        </Route>
        {/* dynamic routing */}
        <Route path="/user/:id/:name" element={<User></User>}></Route>
        {/* redirect to another path  */}
        <Route path="/home" element={<Navigate to="/"></Navigate>}></Route>
        {/* default routing */} 
        {/* if none of the above routes march then this page is going to be displayed, */}
        <Route path="*" element={<PageNotFound></PageNotFound>}></Route>
      </Routes>
    </>
  );
}

// /about/company
// /about/ceo

function Home() {
  return (
    <>
      <div>Home page</div>
      <h1>Our company is the best</h1>
    </>
  );
}

function About() {
  return (
    <>
      <div>About page</div>
      <p>
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Hic, alias
        dignissimos voluptate inventore dolor non unde ea molestias numquam
        odio. Eaque mollitia magni corrupti non est ratione quod voluptatibus
        excepturi.
      </p>
      <Outlet></Outlet>
    </>
  );
}

function Company() {
  return (
    <>
      <h2>we never layoff</h2>
      <Outlet></Outlet>
    </>
  );
}

function Ceo() {
  return (
    <>
      <h2>very good guy, best ceo</h2>
      <Outlet></Outlet>
    </>
  );
}

function User() {
  // const paramsObj=useParams();
//   console.log(paramsObj);
  const [users, setUsers] = useState(null);
  const {id,name} = useParams();
  useEffect(() => {
    async function getUsers() {
      let resp = await fetch(`https://fakestoreapi.com/users/${id}`);
      let data = await resp.json();
      console.log(data);
      setUsers(data);
    }
    getUsers();
  }, []);

  return (
    <>
      {users == null ? (
        <h1>...Loading</h1>
      ) : (
        <>
          <div>I am User {id}</div>
          <li>
            {users.name.firstname}
            {users.name.lastname}
          </li>
          <li>{users.phone}</li>
        </>
      )}
    </>
  );
}

function PageNotFound(){
    return(
        <div>
            <h1>Oops, Wrong Page !!!!</h1>
        </div>
    )
}

export default Routing;
