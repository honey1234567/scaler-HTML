import React from "react";
import styleObj from "../style.module.css";
function ProductList({product}) {
    // const product=props.product;
  return (
    <div className={styleObj.product} >
      <img src={product.image} alt="" className={styleObj.product_image} />
      <div className={styleObj.title}>{product.title}</div>
      <div className={styleObj.price}>$ {product.price}</div>
    </div>
  );
}

export default ProductList;
