import React from 'react'

function Home() {
    return (
      <>
        <div>Home page</div>
        <h1>Our company is the best</h1>
      </>
    );
  }

export default Home