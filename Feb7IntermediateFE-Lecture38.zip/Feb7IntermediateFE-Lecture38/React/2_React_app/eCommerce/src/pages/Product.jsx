import React, { useEffect, useState } from "react";
import styleObj from "../style.module.css";
import useFetchList from "../helper/useFetchList";
import ProductList from "../components/ProductList";
import ArrowCircleUpIcon from "@mui/icons-material/ArrowCircleUp";
import ArrowCircleDownIcon from "@mui/icons-material/ArrowCircleDown";
const productUrl = "https://fakestoreapi.com/products";
const categoryUrl="https://fakestoreapi.com/products/categories"
function Product() {
  const [productList, loader] = useFetchList(productUrl);
  const [categoryList, categoryLoader] = useFetchList(categoryUrl);
  const [searchTerm, setSearchTerm] = useState("");
  const[sortDir,setSortDir]=useState(0);
  const[category,setCategory]=useState("all");

  let filteredList = productList;
  if (searchTerm != "") {
    const searchedText = searchTerm.toLowerCase();
    filteredList = filteredList.filter((product) => {
      let productTitle = product.title.toLowerCase();
      return productTitle.includes(searchedText);
    });
    console.log(filteredList);
  }

  if(sortDir!=0){
    if(sortDir==1){
        //sort increasing
        filteredList.sort((a,b)=>{
            return a.price-b.price
        })
    }
    else{
        //sort decreasing
        filteredList.sort((a,b)=>{
            return b.price-a.price
        })
    }
  }

  if(category!="all"){
    filteredList=filteredList.filter((product)=>{
        return product.category==category
    })
  }
  
  return (
    <>
      <header className={styleObj.nav_wrapper}>
        <div className={styleObj.search_sortWrapper}>
          <input
            className={styleObj.search_input}
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          ></input>
          <div className={styleObj.icons_container}>
            <ArrowCircleUpIcon
              fontSize="large"
              style={{ color: "white" }}
              onClick={()=>setSortDir(1)}
            ></ArrowCircleUpIcon>
            <ArrowCircleDownIcon
              fontSize="large"
              style={{ color: "white" }}
              onClick={()=>setSortDir(-1)}
            ></ArrowCircleDownIcon>
          </div>
        </div>
      </header>
      <div className={styleObj.categories_wrapper}>
      <button className={styleObj.category_option} onClick={()=>setCategory("all")}>All</button>
        {
            categoryList.map((category)=>{
            return <button className={styleObj.category_option} onClick={()=>setCategory(category)}>{category}</button>
            })
        }
      </div>
      {loader && <div className={styleObj.loader}></div>}
      <main className={styleObj.product_wrapper}>
        {filteredList.map((product) => {
          return <ProductList key={product.id} product={product}></ProductList>;
        })}
      </main>
    </>
  );
}

export default Product;
