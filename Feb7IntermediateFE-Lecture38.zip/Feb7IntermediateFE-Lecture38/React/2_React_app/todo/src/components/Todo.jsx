import React, { useState } from 'react'
import InputBox from './InputBox';
import List from './List';
function Todo() {
    
    const[tasks,setTasks]=useState([]);
// tasks=>["erfds","trefd"]-> [<li>erferf</li>,<li>erfvdcwaesds</li>]
    
    const handleTask=(inputValue)=>{
        //i want my inputValue to be added in my task array 
        //in this if tasks arr is pointing to 4k, then after pushong my currTask it is still going to point to 4k . so react does not notice any chnage in it's state . i.e. "tasks" arr. so it does not re -render 
        // setTasks(tasks.push(inputValue))

        //to overcome this , we create a new array which is going to point to 8k . in this new array we are going to spread previous tasks and add new task as well. this way react notices a chnage in it's state. from 4k to 8k. so it re-renders the UI . 
        setTasks([...tasks,{id:Date.now(),inputValue}])
    }

    const handleDelete=(id)=>{
        let filteredTasksArr=tasks.filter(obj=>obj.id!=id);
        setTasks(filteredTasksArr)
    }
  return (
    <div>
        <InputBox handleTask={handleTask}></InputBox>
        <List tasks={tasks} handleDelete={handleDelete}></List>
    </div>
  )
}

export default Todo