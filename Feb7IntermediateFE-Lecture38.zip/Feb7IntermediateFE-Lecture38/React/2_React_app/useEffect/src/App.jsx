import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
// import './App.css'
import GetData from './components/GetData'
import Variations from './components/Variations'
import ResizeAwareComponent from './components/ResizeAwareComponent'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    {/* <GetData></GetData> */}
    {/* <Variations></Variations> */}
    <ResizeAwareComponent></ResizeAwareComponent>
    </>
  )
}

export default App
