import React, { useEffect, useState, useRef } from "react";
import styleObject from "./style.module.css";
import useFetchParams from "./useFetchParams";

function InfinteScrolling() {
  const [pageNum, setPageNum] = useState(1);
  const observer = useRef(null);
  console.log(observer);
  // const handleClick = () => {
  //   //get the latest data of pageNum state and then perform the operation
  //   setPageNum((pageNum) => pageNum + 1);
  // };

  const lastElementNode = (node) => {
    console.log(node);
    const target = node;
    //as soon as last node comes up , increase pageNum
    if(loader)  return
    //disconnect yourself from previous call 
    //forget about the previous element. 
    if(observer.current) observer.current.disconnect();
    //set observer on new call
    observer.current = new IntersectionObserver((entries) => {
      const entry = entries[0];
      console.log(entry);
      if (entry.isIntersecting) {
        setPageNum((pageNum) => pageNum + 1);
      }
    });
    if (target) observer.current.observe(target);
  };

  //use my custom hook here
  const [data, loader, error] = useFetchParams(pageNum);
  return (
    <>
      <div>
        {data.map((dataObj, idx) => {
          if (data.length == idx + 1) {
            //last element
            return (
              <div
                key={dataObj.id}
                className={styleObject.book_title}
                ref={(node) => lastElementNode(node)}
              >
                <p>{dataObj.id}</p>
                {dataObj.body}
              </div>
            );
          } else {
            return (
              <div key={dataObj.id} className={styleObject.book_title}>
                <p>{dataObj.id}</p>
                {dataObj.body}
              </div>
            );
          }
        })}
      </div>
      {loader && <div className={styleObject.loader}></div>}
      {error && (
        <div
          style={{
            backgroundColor: "red",
            color: "white",
          }}
        >
          {error}
        </div>
      )}
      <div>{pageNum}</div>
      {/* <div onClick={handleClick}>Next</div> */}
    </>
  );
}

export default InfinteScrolling;
