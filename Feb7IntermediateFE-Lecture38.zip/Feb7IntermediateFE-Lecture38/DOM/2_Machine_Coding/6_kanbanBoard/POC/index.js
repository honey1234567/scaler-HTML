console.log(localStorage);
//data is stored in browser -> so browser stores then extire data of a website by mapping its hostname/domain

//create
localStorage.setItem("name","Abhishek");
localStorage.setItem("age","34");
localStorage.setItem("hobby","eating");
localStorage.setItem("user",JSON.stringify({"name":"Angeline","age":20}))

//get
let data=localStorage.getItem("name")
console.log(data);
console.log(typeof data);
let user=localStorage.getItem("user");
console.log(user);
console.log(typeof user);
console.log(user.name); //caanot access becqause user is still a string and not an object 
user=JSON.parse(user);
console.log(typeof user);
console.log(user.name);

//update
localStorage.setItem("name","Scaler");
let data2=localStorage.getItem("name")
console.log(data2);

//length prop
console.log(localStorage.length);

//delete 
localStorage.removeItem("hobby");
console.log(localStorage);

//to clear entire lcal storage in one go 
localStorage.clear()