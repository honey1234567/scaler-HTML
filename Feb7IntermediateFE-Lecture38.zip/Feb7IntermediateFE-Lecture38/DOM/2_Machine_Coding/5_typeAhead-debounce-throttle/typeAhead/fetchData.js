// const input="India"
// const url=`https://restcountries.com/v3.1/name/${input}`

// console.log("Before");
// const dataPromise= fetch(url);
// dataPromise.then(res=>{
//     console.log(res);
//     // console.log( res.json()); return a promise
//     return res.json()

// })
// .then(data=>{
//     console.log(data);
// })

// console.log("After");
let fetchController=null;
function cancelPrevRequest(){
    fetchController.abort();
}
async function getCountries(keyword){
    if(fetchController!=null){
        cancelPrevRequest()
    }
    const controller=new AbortController(); //ba req ka controller
    try{
        fetchController=controller;
        const resp= await fetch(`https://restcountries.com/v3.1/name/${keyword}`,{signal:controller.signal});
        fetchController-null;
        if(resp.status==404) return [];
        const data= await resp.json();
        return data;
    }
    catch(err){
        console.log("caught error",err.message);
    }
}


export default getCountries
// b-> getCountries-> controller of b is created -> attach signal to req -> fetchController=b ka controller
// ba-> getCountries-> req get aborted 
// bah-> getCountries-> 