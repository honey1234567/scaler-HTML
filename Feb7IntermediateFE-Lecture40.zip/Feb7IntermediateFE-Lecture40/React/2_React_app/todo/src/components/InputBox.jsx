import React,{useState} from 'react'

function InputBox({handleTask}){
    const[inputValue,setInputValue]=useState("");
    const handleInput=(e)=>{
        setInputValue(e.target.value);
    }
    const handleAdd=()=>{
        handleTask(inputValue);
        setInputValue("");
    }
    return <>
    <input type="text" value={inputValue} onChange={handleInput}/>
        <button onClick={handleAdd}>Add</button>
    </>
}

export default InputBox