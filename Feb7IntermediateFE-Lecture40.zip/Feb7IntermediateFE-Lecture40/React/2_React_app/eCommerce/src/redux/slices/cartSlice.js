import {createSlice} from "@reduxjs/toolkit";
const cartSlice=createSlice({
    name:"cart",
    initialState:{
        cartQuantity:0
    },
    reducers:{
        addTocart:(state,action)=>{

        },
        removeFromCart:(state,action)=>{
            
        }
    }

})
console.log(cartSlice);

export const actions=cartSlice.actions;
export default cartSlice;