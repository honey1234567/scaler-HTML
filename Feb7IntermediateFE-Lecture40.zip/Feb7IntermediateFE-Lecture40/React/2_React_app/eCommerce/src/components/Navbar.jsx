import React from 'react'
import styleObj from "../style.module.css"
import { Link} from "react-router-dom";
function Navbar() {
  return (
    <>
    <ul className={styleObj.navbar}>
        <Link to="/"><li>Home</li></Link>
        <Link to="/about"><li>About</li></Link>
        <Link to="/products"><li>Products</li></Link>
        <Link to="/cart"><li>Cart</li></Link>
    </ul>
    </>
  )
}

export default Navbar