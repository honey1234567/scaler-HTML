import {createSlice} from "@reduxjs/toolkit";

const todoSlice=createSlice({
    name:"todo",
    initialState:{
        inputValue:"",
        tasksArr:[]
    },
    reducers:{
        updateInput:(state,obj)=>{
            // console.log(obj);
            //i get the typed task , and then update my state 
            state.inputValue=obj.payload;
        },
        addTask:(state)=>{
            //take the inputValue state and add it to my tasksArr .
            const newTasksArr=[...state.tasksArr,state.inputValue];
            state.tasksArr=newTasksArr;
            state.inputValue="";

        }
    }
})

export default todoSlice