//1 create an instance -> create abortController 
const controller=new AbortController();
// console.log(controller);
// (async function(){
//     try{
//         //2 attach signal to fetch request
//         const responsePromise=await fetch('https://restcountries.com/v3.1/name/bah',{signal:controller.signal});
//         //3 we call abort function 
//         console.log("request is sent");
//         controller.abort();
//         const data=await responsePromise.json();
//         console.log(data);
//     }
//     catch(err){
//         console.log(err);
//     }
// })()

// implement-> request timeout -> response -> 0.2 sec-> abort
setTimeout(()=>{
    controller.abort()
},200)

async function getRes(){
    try{
         //2 attach signal to fetch request
         const responsePromise=await fetch('https://restcountries.com/v3.1/name/ch',{signal:controller.signal});
         console.log("request is sent");
         const data=await responsePromise.json();
         console.log(data);
    }
    catch(err){
        console.log(err);
        console.log(err.message);
        console.log(err.name);
    }
}
getRes()