let pizzaPrice=500;

function apply60(){
    console.log(`New price-> ${0.4*pizzaPrice}`);
}

function throttle(fn,delay){
    let flag=true;
    return function(...args){
        if(flag){
            fn(...args)
            console.log("coupon has been applied");
            flag=false;
            setTimeout(()=>{
                flag=true;
            },delay)
        }
        else{
            console.log("coupon not valid");
        }
    }
}

const throttledFn=throttle(apply60,5000);
throttledFn()
throttledFn()
throttledFn()
setTimeout(()=>{
    throttledFn()
},6000)
    