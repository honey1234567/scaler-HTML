const inputBox=document.querySelector("#search-input");
const suggestionBox=document.querySelector(".suggestion-box");
import getCountries from "./fetchData.js"
// inputBox.addEventListener("input",handleSuggestion);

async function handleSuggestion(e){
    let inputText=e.target.value;
    console.log(inputText);
    let data= await getCountries(inputText)
    console.log(inputText,data);
    //populate the data
    populateSuggestions(data)
}

function populateSuggestions(data){
    // data->obj->name->common
    if(data.length==0) return;
    suggestionBox.innerHTML=''
    const fragment=document.createDocumentFragment();
    data.forEach(obj=>{
        let countryName=obj.name.common;
        const li=document.createElement('li')
        li.innerText=countryName;
        fragment.appendChild(li);
    })
    suggestionBox.appendChild(fragment);
}

function debounce(fn,delay){
    let timerId;
    return function(...args){
        clearTimeout(timerId)
        timerId=setTimeout(()=>{
            fn(...args) //network call
        },delay)
    }
}
//this magic fn is going to wait for next input for 300ms and then only make network call 
let debouncedFn=debounce(handleSuggestion,300);
inputBox.addEventListener("input",debouncedFn)



