whatsapp group link : https://chat.whatsapp.com/J6KEhE8tvbOIVE4GYk6Oju

12/02/2024
https://developer.mozilla.org/en-US/docs/Web/CSS/background-repeat

14/02/2024

https://flukeout.github.io/

https://developer.mozilla.org/en-US/docs/Web/CSS/:nth-child

https://developer.mozilla.org/en-US/docs/Web/CSS/:last-child

https://www.w3schools.com/cssref/trysel.php?selector=p:last-child

23/02/2024
https://flexboxfroggy.com/
https://cssgridgarden.com/

26/02/2024
https://www.codecademy.com/resources/docs/css/inheritance

08/03/2024
https://www.youtube.com/playlist?list=PL-Jc9J83PIiEW-8x9Js6m5UixBUciYaMV
https://lodash.com/docs/4.17.15#cloneDeep

27/03/2024
https://javascript.info/map-set
https://javascript.info/weakmap-weakset

26/04/2024
https://developer.mozilla.org/en-US/docs/Web/API/clearInterval

03/05/2024
https://www.semrush.com/blog/semantic-html5-guide/

06/05/2024
https://reactrouter.com/en/main/start/tutorial

10/05/2024
https://react.dev/learn/extracting-state-logic-into-a-reducer