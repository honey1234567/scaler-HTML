// var a=10;
// function fn(){
//     var b=100;
//     console.log("i am fun");
// }
// console.log(fn)
// fun()


var a=25;
console.log(a);
console.log(foo);
foo()
function foo(){
    var a=50;
    console.log("hello");
}
console.log(a)


// real=f3{}
// real();
// function real() {
//     console.log("I am real. Always run me");
// }
// function real() {
//     console.log("No I am real one ");
// }

// function real() {
//     console.log("You both are wasted");
// }
