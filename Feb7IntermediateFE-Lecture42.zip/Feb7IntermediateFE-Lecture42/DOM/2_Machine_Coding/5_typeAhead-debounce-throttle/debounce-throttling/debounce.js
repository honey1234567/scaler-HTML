function debounce(fn,delay){
    let timeoutId=null;
    return function(){
        if(timeoutId){
            console.log("resetting the timers");
            clearTimeout(timeoutId)
        }
        timeoutId=setTimeout(()=>{
            fn()
        },delay)
    }
}

function printHello(){
    console.log("hello");
    console.timeEnd();
}


let debouncedFn=debounce(printHello,2000)
console.time()
debouncedFn()

setTimeout(()=>{
    debouncedFn()
    setTimeout(()=>{
        debouncedFn()
        setTimeout(()=>{
            debouncedFn()
        },1000)
    },1000)
},1000);