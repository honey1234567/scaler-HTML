const url="https://restcountries.com/v3.1/name/bah"
// cache={
//     "https://restcountries.com/v3.1/name/bah":{
//         data: [{},{}],
//         timeStamp:"21345678976543567"
//     }
// }


function cachedFetch(expiry){
    //create cache
    const cache={};
    return async function (url){
        //check if present in cache
        if(cache[url]){
            console.log("req is being served from cache");
            const cachedData=cache[url];
            const cachedTime=cachedData.timeStamp; //in ms
            const currentTime=new Date().getTime(); //cureent time in ms 
            if(currentTime-cachedTime < expiry*60*60*1000){
                return cachedData.data;
            }
        }


        //make req 
        const response=await fetch(url);
        const data=await response.json();

        //store in cache
        cache[url]={
            data,
            timeStamp:new Date().getTime() //time elapsed from 1st January 1970 to present date in millisecods -> epoch 
        }

        return data;
    }
}

const cachedFn=cachedFetch(48) //in hours 
let resProm=cachedFn(url)
resProm.then(data=>{
    console.log(data);
})
.catch(err=>{
    console.log(err);
})

setTimeout(()=>{
    let resProm=cachedFn(url)
resProm.then(data=>{
    console.log(data);
})
.catch(err=>{
    console.log(err);
})
},2000)




// past  time -> 1713199508

// cuirrent time -> 1713199525


// 130000ms -> 1300 sec -> 130/60 min -> 13/6-> 2.2min 

// 1min-> 60 sec -> 1min 
// 1sec= 1/60 min 
// <2days -> 2*24*60*60*1000