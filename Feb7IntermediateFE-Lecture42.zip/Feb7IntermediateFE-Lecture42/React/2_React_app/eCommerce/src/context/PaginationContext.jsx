import React, { createContext, useContext, useState } from 'react'
export const PaginationWrapper=createContext();
function PaginationContext({children}) {
    const [pageNum,setPageNum]=useState(1);
    const [pageSize,setPageSize]=useState(4);
  return (
    <PaginationWrapper.Provider value={{pageNum,setPageNum,pageSize,setPageSize}}>
        {children}
    </PaginationWrapper.Provider>
  )
}
export const usePaginationContext=()=>useContext(PaginationWrapper)
export default PaginationContext