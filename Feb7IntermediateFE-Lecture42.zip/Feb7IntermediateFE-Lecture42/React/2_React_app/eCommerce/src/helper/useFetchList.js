import React, { useEffect, useState } from "react";
export default function useFetchList(url){
    const [list, setList] = useState([]);
    const [loader,setLoader]=useState(true);
    useEffect(() => {
        (async function () {
          setLoader(true);
          let resp = await fetch(url);
          let data = await resp.json();
          setLoader(false);
          console.log(data);
          setList([...data]);
        })();
      }, []);
      return [list,loader];
}