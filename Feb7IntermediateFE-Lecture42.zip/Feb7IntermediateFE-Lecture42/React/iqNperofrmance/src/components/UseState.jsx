import { useState } from "react";
import React from 'react'
function UseState() {
    const [count, setCount] = useState(0);
    const handleCount = () => {
      setInterval(()=>{
        console.log(count);
        //in this case our state is dependent on prev state 
        setCount(prevCount=>prevCount+1);
      },1000)
    }
    return (
        <>
            <h3>{count}</h3>
            <button onClick={handleCount}>Increment</button>
        </>
    )
}

export default UseState