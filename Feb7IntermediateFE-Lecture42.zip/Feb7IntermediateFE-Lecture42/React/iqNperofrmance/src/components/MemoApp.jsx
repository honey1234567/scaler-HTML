//

import React, { useState } from 'react';

export default function MemoApp() {
    const [name, setName] = useState('');
    const [address, setAddress] = useState('');
    return (
        <>
            <label>
                Name{': '}
                <input value={name} onChange={e => setName(e.target.value)} />
            </label>
            <label>
                Address{': '}
                <input value={address} onChange={e => setAddress(e.target.value)} />
            </label>
            {/* this memogreeting component re renders if there is a asta echnage in name or address  */}
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
            <MemoGreeting name={name} />
        </>
    );
}

const MemoGreeting=React.memo(Greeting);
function Greeting({ name }) {
    console.log("Greeting was rendered at", new Date().toLocaleTimeString());
    return <h3>Hello{name && ', '}{name}!</h3>;
}