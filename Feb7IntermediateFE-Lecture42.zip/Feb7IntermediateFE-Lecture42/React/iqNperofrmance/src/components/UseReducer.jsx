import React,{useState,useReducer} from 'react'

function UseReducer() {
    const reducer=(prevState,action)=>{
        switch (action) {
            case "increment":
                return prevState + 1;
            case "decrement":
                return prevState - 1;
            case "IncrementByFive":
                return prevState + 5;
            case "DecrementByFive":
                return prevState - 5;
            default:
                return prevState;
        }
    }
    const [count, dispatch] = useReducer(reducer,0);

    // const increment = () => {
    //     setCount(count => count + 1);
    // }
    // const decrement = () => {
    //     setCount(count => count - 1);
    // }
    // const incrementBy5 = () => {

    //     setCount(count => count + 5);
    // }
    // const decrementBy5 = () => {
    //     setCount(count => count - 5);

    // }
  return (
    <>
    <h1>Reducer_counter</h1>
    <h3> Count {count}</h3>
    {/* <button onClick={increment}>+</button>
    <button onClick={decrement}>-</button>
    <button onClick={incrementBy5}>+5</button>
    <button onClick={decrementBy5}>-5</button>     */}
    <button onClick={()=>dispatch("increment")}>+</button>
    <button onClick={()=>dispatch("decrement")}>-</button>
    <button onClick={()=>dispatch("IncrementByFive")}>+5</button>
    <button onClick={()=>dispatch("DecrementByFive")}>-5</button>    
    </>
  )
}

export default UseReducer


const [state, dispatch] = React.useReducer(
    fetchUsersReducer,
    {
      users: [
        { name: 'John', subscribred: false },
        { name: 'Jane', subscribred: true },
      ],
      loading: false,
      error: false,
    },
  );
  