import React from "react";
// we need our state as well as logics 
import {useSelector,useDispatch} from "react-redux";
import counterSlice from "../redux/counterSlice";
console.log(counterSlice);
const {actions}=counterSlice;
function Counter() {
    //store->slice->state name 
    const count=useSelector((store)=>{return store.counterState.count});
    console.log(count);
    const dispatch=useDispatch();
//   const handleIncrement = () => {};
  const handleDecrement = () => {
    if(count<1){
        alert("Count cannot be negative");
    }
    dispatch(actions.decrement())
  };
  return (
    <div>
      <button onClick={()=>dispatch(actions.increment())}>+</button>
      <p>{count}</p>
      <button onClick={handleDecrement}>-</button>
    </div>
  );
}

export default Counter;
