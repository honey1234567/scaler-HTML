import React from 'react'
function About() {
    return (
      <>
        <div>About page</div>
        <p>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Hic, alias
          dignissimos voluptate inventore dolor non unde ea molestias numquam
          odio. Eaque mollitia magni corrupti non est ratione quod voluptatibus
          excepturi.
        </p>
      </>
    );
  }

export default About