import React, { useEffect, useState } from "react";

function Variations() {
  const [tasks, setTasks] = useState([]);
  const [inputValue, setInputValue] = useState("");

  const handleTask = () => {
    setTasks([...tasks, { id: Date.now(), inputValue }]);
    setInputValue("");
  };

  const handleInput = (e) => {
    setInputValue(e.target.value);
  };

  const handleDelete = (id) => {
    let filteredTasksArr = tasks.filter((obj) => obj.id != id);
    setTasks(filteredTasksArr);
  };

//   first variation -> w/o dependency array 
//   useEffect(()=>{
//     //called when components is rendred for the first time and then everytime state is changed. 
//     console.log("i am useEffect 1");
//   })

  //   second variation -> with empty dependency array 
//   useEffect(()=>{
//     //called when components is rendred for the first time. 
//     console.log("i am useEffect 2");
//   },[])

  //   third variation -> with dependency array 
//   useEffect(()=>{
//     //called when components is rendred for the first time, and then called only when the states present in dependency array are chnaged 
//     console.log("i am useEffect 3");
//   },[tasks])

//    //   fourth variation -> with dependency array + cleanup 
//    useEffect(()=>{
//     //called when components is rendred for the first time, and then called only when the states present in dependency array are chnaged 
//     console.log("i am useEffect 4");
//     let id=setInterval(()=>{console.log("hello")},2000);
//     //cleanup function -> just before next useEffect is called , cleanup function is called first. this cleanup function is called when there isa chnage in tasks state. so before new useEffexct is called , old useEffect's cleanup is called first
//     return ()=>{
//         clearInterval(id);
//         console.log("cleanup beofre useEffect 4 is called");
//     }
//   },[tasks])

    //  //   fifth variation -> with empty dependency array + cleanup  
    //  useEffect(()=>{
    //     console.log("i am useEffect 5");
    //     let id=setInterval(()=>{console.log("hello")},2000);
    //     //cleanup function -> just before next useEffect is called , cleanup function is called first. this cleanuop will be called only when component is unmounted 
    //     return ()=>{
    //         clearInterval(id);
    //         console.log("cleanup before useEffect 5 is called");
    //     }
    //   },[])

     //   sixth variation -> w/o dependency array + cleanup 
     useEffect(()=>{
        console.log("i am useEffect 6");
        let id=setInterval(()=>{console.log("hello")},2000);
        //cleanup function -> just before next useEffect is called , cleanup function is called first. this cleanuop will be called if nay of the state is chnaged. 
        return ()=>{
            clearInterval(id);
            console.log("cleanup before useEffect 6 is called");
        }
      })

console.log("render");
  return (
    <div>
      <input type="text" value={inputValue} onChange={handleInput} />
      <button onClick={handleTask}>Add</button>

      <div className="list">
        <ul>
          {tasks.map(({ inputValue: task, id }) => (
            <div key={id}>
              <li>{task}</li>
              <button onClick={() => handleDelete(id)}>Delete</button>
            </div>
          ))}
        </ul>
      </div>
    </div>
  );
}
export default Variations;
