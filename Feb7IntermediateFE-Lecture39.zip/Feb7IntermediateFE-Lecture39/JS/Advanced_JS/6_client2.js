// console.log("i am client2",a)
// foo()
// fun()
// var b="from client 2"

import { increment,getCount } from './4_lib.js';

increment()
console.log(getCount());

// c=1000;
console.log(this);