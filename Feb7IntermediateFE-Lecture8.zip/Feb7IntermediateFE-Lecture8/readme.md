whatsapp group link : https://chat.whatsapp.com/J6KEhE8tvbOIVE4GYk6Oju

12/02/2024
https://developer.mozilla.org/en-US/docs/Web/CSS/background-repeat

14/02/2024

https://flukeout.github.io/

https://developer.mozilla.org/en-US/docs/Web/CSS/:nth-child

https://developer.mozilla.org/en-US/docs/Web/CSS/:last-child

https://www.w3schools.com/cssref/trysel.php?selector=p:last-child

23/02/2024
https://flexboxfroggy.com/
https://cssgridgarden.com/