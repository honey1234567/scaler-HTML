import React, { useEffect, useState } from 'react'

function GetData() {
    const[data,setData]=useState(null); //data is an array 

    // infinte loop 
    // async function getData(){
    //     console.log("i am being re-rendered, SAVE ME");
    //     let res=await fetch("https://jsonplaceholder.typicode.com/users");
    //     let data=await res.json(); //arr of obj -> data of 10users
    //     setData(data)
    // }
    // getData()

    useEffect(()=>{
        async function getData(){
        console.log("useEffect called once");
            let res=await fetch("https://jsonplaceholder.typicode.com/users");
            let data=await res.json(); //arr of obj -> data of 10users
            
            //artificial delay to observe the loader
            setTimeout(()=>setData(data),2000);
        }
        getData()
    },[])
  return (
    <>
    {data==null?
    <h1>Loading Data .......</h1>:
    data.map(({name,id})=>
        <li key={id}>{name}</li>
    )}
    </>
  )
}

export default GetData